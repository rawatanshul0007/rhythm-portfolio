(function(){
// WRITING SAMPLES CONFIG. Replace the empty fields with real samples.
// Fields: title, category, summary, url (genuine, verified URL only), thumb (optional, unused until added)
var samples=[
 {category:'Educational Content',title:'',summary:'',url:'',thumb:''},
 {category:'Travel & Airline Content',title:'',summary:'',url:'',thumb:''},
 {category:'E-commerce Content',title:'',summary:'',url:'',thumb:''},
 {category:'Travel & Music Editorial',title:'',summary:'',url:'',thumb:''},
 {category:'SEO-Optimized Articles',title:'',summary:'',url:'',thumb:''}
];
var $=function(q){return document.querySelector(q)};
var box=$('#samples');
samples.forEach(function(s,i){
 var real=!!s.title,link=real&&s.url,el=document.createElement(link?'a':'article');
 el.className='card rv';
 if(link){el.href=s.url;el.target='_blank';el.rel='noopener'}
 var c=document.createElement('span');c.className='cat';c.textContent='0'+(i+1)+' · '+s.category;
 var h=document.createElement('h3');h.textContent=real?s.title:'Writing sample coming soon';
 var p=document.createElement('p');p.textContent=real?s.summary:'Awaiting a real writing sample for this category.';
 el.append(c,h,p);box.appendChild(el);
});
var nav=$('.nav'),bar=$('.progress'),menu=$('#menu'),btn=$('.burger');
function onScroll(){
 var h=document.documentElement;nav.classList.toggle('stuck',scrollY>10);
 bar.style.transform='scaleX('+(scrollY/((h.scrollHeight-innerHeight)||1))+')';
}
addEventListener('scroll',onScroll,{passive:true});onScroll();
function toggle(o){btn.setAttribute('aria-expanded',o);btn.setAttribute('aria-label',o?'Close menu':'Open menu');menu.classList.toggle('open',o)}
btn.addEventListener('click',function(){toggle(btn.getAttribute('aria-expanded')!=='true')});
menu.addEventListener('click',function(e){if(e.target.closest('a'))toggle(false)});
addEventListener('keydown',function(e){if(e.key==='Escape'){toggle(false);btn.focus()}});
if('IntersectionObserver' in window){
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});
 document.querySelectorAll('.rv').forEach(function(n){io.observe(n)});
 var links=[].slice.call(document.querySelectorAll('nav a:not(.btn)'));
 var so=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)links.forEach(function(a){a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id)})})},{rootMargin:'-45% 0px -50% 0px'});
 document.querySelectorAll('main section[id]').forEach(function(s){so.observe(s)});
}else{document.querySelectorAll('.rv').forEach(function(n){n.classList.add('in')})}
$('#yr').textContent=new Date().getFullYear();
$('#copy').addEventListener('click',function(){
 var s=$('#copied');
 (navigator.clipboard?navigator.clipboard.writeText('writetorhythmarya@gmail.com'):Promise.reject()).then(function(){s.textContent='Email copied'},function(){s.textContent='Copy failed. Please select the email manually.'});
});
})();
